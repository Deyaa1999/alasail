<?php
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json');

$action    = $_POST['action'] ?? '';
$productId = (int)($_POST['product_id'] ?? 0);
$qty       = (int)($_POST['qty'] ?? 1);

if (!$productId) {
    echo json_encode(['success' => false, 'message' => 'Invalid product']);
    exit;
}

switch ($action) {
    case 'add':
        addToCart($productId, max(1, $qty));
        break;
    case 'update':
        updateCartQty($productId, $qty);
        break;
    case 'remove':
        removeFromCart($productId);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Unknown action']);
        exit;
}

$cartItems   = getCartItems();
$cartTotal   = getCartTotal();
$cartCount   = getCartCount();
$shipping    = $cartTotal > 5000 ? 0 : 150;
$grandTotal  = $cartTotal + $shipping;

// Item subtotal
$itemSubtotal = '';
$cart = getCart();
if (isset($cart[$productId])) {
    $res = $conn->query("SELECT price FROM products WHERE id=$productId");
    if ($res && $r = $res->fetch_assoc()) {
        $itemSubtotal = formatPrice($r['price'] * $cart[$productId]);
    }
}

echo json_encode([
    'success'        => true,
    'cart_count'     => $cartCount,
    'formatted_total'=> formatPrice($grandTotal),
    'item_subtotal'  => $itemSubtotal,
    'shipping'       => $shipping > 0 ? formatPrice($shipping) : 'Free',
    'shipping_note'  => $shipping > 0 ? 'Add ' . formatPrice(5000 - $cartTotal) . ' more for free shipping!' : '🎉 You have free shipping!',
]);
