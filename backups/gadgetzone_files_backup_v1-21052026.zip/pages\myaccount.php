<?php
require_once __DIR__ . '/../includes/functions.php';
requireLogin();
$pageTitle = 'My Account — GadgetZone';
$user = getCurrentUser();
$tab  = $_GET['tab'] ?? 'dashboard';
$success = $error = '';

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $tab === 'profile') {
    $fn   = $conn->real_escape_string(trim($_POST['first_name'] ?? ''));
    $ln   = $conn->real_escape_string(trim($_POST['last_name'] ?? ''));
    $ph   = $conn->real_escape_string(trim($_POST['phone'] ?? ''));
    $addr = $conn->real_escape_string(trim($_POST['address'] ?? ''));
    $city = $conn->real_escape_string(trim($_POST['city'] ?? ''));
    $conn->query("UPDATE users SET first_name='$fn',last_name='$ln',phone='$ph',address='$addr',city='$city' WHERE id={$user['id']}");
    $success = 'Profile updated successfully!';
    $user = getCurrentUser();
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $tab === 'password') {
    $current = $_POST['current_password'] ?? '';
    $new     = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    if (!password_verify($current, $user['password'])) {
        $error = 'Current password is incorrect.';
    } elseif (strlen($new) < 6) {
        $error = 'New password must be at least 6 characters.';
    } elseif ($new !== $confirm) {
        $error = 'New passwords do not match.';
    } else {
        $hash = password_hash($new, PASSWORD_DEFAULT);
        $conn->query("UPDATE users SET password='$hash' WHERE id={$user['id']}");
        $success = 'Password updated successfully!';
    }
}

$uid = $user['id'];

// Stats
$totalOrders    = $conn->query("SELECT COUNT(*) FROM orders WHERE user_id=$uid")->fetch_row()[0];
$deliveredOrders= $conn->query("SELECT COUNT(*) FROM orders WHERE user_id=$uid AND status='delivered'")->fetch_row()[0];
$totalSpentRow  = $conn->query("SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE user_id=$uid AND status!='cancelled'")->fetch_row()[0];

// Orders
$orders = $conn->query("SELECT o.*, (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id=o.id) AS item_count FROM orders o WHERE o.user_id=$uid ORDER BY o.created_at DESC ".($tab==='dashboard' ? 'LIMIT 5' : ''));

$tabs = [
    'dashboard' => ['icon'=>'📊','label'=>'Dashboard'],
    'orders'    => ['icon'=>'🛍️','label'=>'My Orders'],
    'profile'   => ['icon'=>'👤','label'=>'Profile'],
    'password'  => ['icon'=>'🔒','label'=>'Change Password'],
];

$initials = strtoupper(substr($user['first_name'],0,1).substr($user['last_name'],0,1));
require_once __DIR__ . '/../includes/header.php';
?>

<div class="container" style="padding-top:24px">
    <div class="breadcrumb"><a href="/GadgetZone/index.php">Home</a> <span>›</span> My Account</div>
    <div class="page-hero"><h1 class="page-hero-title">My Account</h1></div>

    <div class="account-layout">
        <!-- SIDEBAR -->
        <aside class="account-sidebar">
            <div class="account-profile">
                <div class="account-avatar">
                    <?php if ($user['avatar']): ?>
                    <img src="/GadgetZone/assets/uploads/avatars/<?= htmlspecialchars($user['avatar']) ?>" alt="">
                    <?php else: ?>
                    <?= $initials ?>
                    <?php endif; ?>
                </div>
                <div class="account-name"><?= htmlspecialchars($user['first_name'].' '.$user['last_name']) ?></div>
                <div class="account-email"><?= htmlspecialchars($user['email']) ?></div>
            </div>
            <nav class="account-nav">
                <?php foreach ($tabs as $key => $t): ?>
                <a href="?tab=<?= $key ?>" class="<?= $tab===$key ? 'active' : '' ?>"><?= $t['icon'] ?> <?= $t['label'] ?></a>
                <?php endforeach; ?>
                <a href="/GadgetZone/pages/logout.php" class="danger">🚪 Logout</a>
            </nav>
        </aside>

        <!-- CONTENT -->
        <div class="account-content">
            <?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
            <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

            <?php if ($tab === 'dashboard'): ?>
            <div class="account-panel">
                <h2 style="margin-bottom:4px">Welcome back, <?= htmlspecialchars($user['first_name']) ?>! 👋</h2>
                <p style="color:var(--text2);margin-bottom:24px">Here's a summary of your account activity</p>
                <div class="stat-cards">
                    <div class="stat-card"><div class="stat-card-num"><?= $totalOrders ?></div><div class="stat-card-label">Total Orders</div></div>
                    <div class="stat-card"><div class="stat-card-num"><?= $deliveredOrders ?></div><div class="stat-card-label">Delivered</div></div>
                    <div class="stat-card"><div class="stat-card-num"><?= formatPrice($totalSpentRow) ?></div><div class="stat-card-label">Total Spent</div></div>
                </div>
                <div class="panel-title">Recent Orders</div>
                <?php if ($orders->num_rows === 0): ?>
                <div class="empty-state" style="padding:40px 0"><div class="empty-icon">📦</div><h3>No orders yet</h3><p>Start shopping to see your orders here</p><a href="/GadgetZone/pages/shop.php" class="btn-primary" style="margin-top:16px">Shop Now</a></div>
                <?php else: ?>
                <table class="orders-table">
                    <thead><tr><th>Order #</th><th>Date</th><th>Total</th><th>Status</th><th>Payment</th></tr></thead>
                    <tbody>
                    <?php while ($o = $orders->fetch_assoc()): ?>
                    <tr>
                        <td><span style="color:var(--accent);font-weight:600"><?= htmlspecialchars($o['order_number']) ?></span></td>
                        <td><?= date('M j, Y', strtotime($o['created_at'])) ?></td>
                        <td><?= formatPrice($o['total_amount']) ?></td>
                        <td><?= statusBadge($o['status']) ?></td>
                        <td><?= htmlspecialchars(ucfirst($o['payment_method'])) ?></td>
                    </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>

            <?php elseif ($tab === 'orders'): ?>
            <div class="account-panel">
                <div class="panel-title">My Orders</div>
                <?php if ($orders->num_rows === 0): ?>
                <div class="empty-state" style="padding:40px 0"><div class="empty-icon">📦</div><h3>No orders yet</h3><a href="/GadgetZone/pages/shop.php" class="btn-primary" style="margin-top:16px">Shop Now</a></div>
                <?php else: ?>
                <div style="overflow-x:auto">
                <table class="orders-table">
                    <thead><tr><th>Order #</th><th>Date & Time</th><th>Items</th><th>Total</th><th>Status</th><th>Payment</th></tr></thead>
                    <tbody>
                    <?php while ($o = $orders->fetch_assoc()): ?>
                    <tr>
                        <td><span style="color:var(--accent);font-weight:600"><?= htmlspecialchars($o['order_number']) ?></span></td>
                        <td><?= date('M j, Y g:ia', strtotime($o['created_at'])) ?></td>
                        <td><?= $o['item_count'] ?> item<?= $o['item_count']!==1?'s':'' ?></td>
                        <td><?= formatPrice($o['total_amount']) ?></td>
                        <td><?= statusBadge($o['status']) ?></td>
                        <td><?= htmlspecialchars(ucfirst($o['payment_method'])) ?></td>
                    </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
                </div>
                <?php endif; ?>
            </div>

            <?php elseif ($tab === 'profile'): ?>
            <div class="account-panel">
                <div class="panel-title">Profile Information</div>
                <form method="POST">
                    <input type="hidden" name="tab" value="profile">
                    <div class="form-grid" style="gap:16px">
                        <div class="form-group">
                            <label class="form-label">First Name</label>
                            <input type="text" name="first_name" class="form-input" value="<?= htmlspecialchars($user['first_name']) ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="last_name" class="form-input" value="<?= htmlspecialchars($user['last_name']) ?>" required>
                        </div>
                        <div class="form-group full">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-input" value="<?= htmlspecialchars($user['email']) ?>" disabled>
                            <small style="color:var(--text3);font-size:12px">Email cannot be changed</small>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Phone Number</label>
                            <input type="text" name="phone" class="form-input" value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">City</label>
                            <input type="text" name="city" class="form-input" value="<?= htmlspecialchars($user['city'] ?? '') ?>">
                        </div>
                        <div class="form-group full">
                            <label class="form-label">Address</label>
                            <textarea name="address" class="form-textarea"><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
                        </div>
                    </div>
                    <button type="submit" class="btn-primary" style="margin-top:16px">Save Changes</button>
                </form>
            </div>

            <?php elseif ($tab === 'password'): ?>
            <div class="account-panel">
                <div class="panel-title">Change Password</div>
                <form method="POST" style="max-width:400px">
                    <input type="hidden" name="tab" value="password">
                    <div class="auth-form">
                        <div class="form-group">
                            <label class="form-label">Current Password <span class="required">*</span></label>
                            <input type="password" name="current_password" class="form-input" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">New Password <span class="required">*</span></label>
                            <input type="password" name="new_password" class="form-input" placeholder="Min 6 characters" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Confirm New Password <span class="required">*</span></label>
                            <input type="password" name="confirm_password" class="form-input" required>
                        </div>
                        <button type="submit" class="btn-primary">Update Password</button>
                    </div>
                </form>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
