<?php
/**
 * Al Asail Equine Veterinary Supplies — Home Page
 */

$pageTitle = 'Al Asail — Professional Equine Veterinary Supplies Jordan';
require_once __DIR__ . '/includes/header.php';

// Fetch Featured Products (up to 6)
$featured_res = $conn->query("
    SELECT p.*, c.name AS cat_name 
    FROM products p 
    JOIN categories c ON c.id = p.category_id 
    WHERE p.featured = 1 
    ORDER BY p.id ASC 
    LIMIT 6
");
$featured_products = [];
if ($featured_res) {
    while ($row = $featured_res->fetch_assoc()) {
        $featured_products[] = $row;
    }
}

// Fetch New Arrivals (up to 4)
$arrivals_res = $conn->query("
    SELECT p.*, c.name AS cat_name 
    FROM products p 
    JOIN categories c ON c.id = p.category_id 
    ORDER BY p.created_at DESC, p.id DESC 
    LIMIT 4
");
$new_arrivals = [];
if ($arrivals_res) {
    while ($row = $arrivals_res->fetch_assoc()) {
        $new_arrivals[] = $row;
    }
}

// Fetch Deal of the Day — first product marked as Limited Time Offer
$deal_res = $conn->query("
    SELECT p.*, c.name AS cat_name 
    FROM products p 
    JOIN categories c ON c.id = p.category_id 
    WHERE p.limited_time_offer = 1 
    ORDER BY p.id DESC
    LIMIT 1
");
$deal_product = ($deal_res && $deal_res->num_rows) ? $deal_res->fetch_assoc() : null;

// Fallback: use first featured product
if (!$deal_product && !empty($featured_products)) {
    $deal_product = $featured_products[0];
}
?>

<!-- ── 1. HERO SECTION ── -->
<section class="hero">
    <div class="hero-inner container">
        <div class="hero-content">
            <h1 class="hero-title">Professional<br>Equine Veterinary<br><span class="hero-title-accent">Care.</span></h1>
            <p class="hero-desc">Your trusted source for certified horse medicines, supplements, horseshoes, and veterinary supplies — delivered with expertise and care.</p>
            <div class="hero-ctas">
                <a href="/GadgetZone/pages/shop.php" class="btn-primary">Shop Products 🐎</a>
                <a href="/GadgetZone/pages/shop.php?badge=SALE" class="btn-outline">View Offers ⚕️</a>
            </div>
            <div class="hero-stats">
                <div class="stat">
                    <div class="stat-number">500+</div>
                    <div class="stat-label">Products</div>
                </div>
                <div class="stat">
                    <div class="stat-number">10K+</div>
                    <div class="stat-label">Horses Treated</div>
                </div>
                <div class="stat">
                    <div class="stat-number">4.9★</div>
                    <div class="stat-label">Vet Rating</div>
                </div>
            </div>
        </div>
        <div class="hero-image">
            <img src="/GadgetZone/assets/images/hero-horse.jpg" alt="Professional Equine Veterinary Care — Al Asail">
        </div>
    </div>
</section>

<!-- ── 2. FEATURE STRIP ── -->
<section class="feature-strip">
    <div class="feature-strip-inner container">
        <div class="feature-item">
            <div class="feature-icon">🔄</div>
            <div class="feature-text">
                <strong>Easy Returns</strong>
                <span>7-day return guarantee</span>
            </div>
        </div>
        <div class="feature-item">
            <div class="feature-icon">🩺</div>
            <div class="feature-text">
                <strong>Vet Approved</strong>
                <span>All products certified</span>
            </div>
        </div>
        <div class="feature-item">
            <div class="feature-icon">📞</div>
            <div class="feature-text">
                <strong>Expert Support</strong>
                <span>Veterinary consultation</span>
            </div>
        </div>
        <div class="feature-item">
            <div class="feature-icon">🔒</div>
            <div class="feature-text">
                <strong>Secure Payment</strong>
                <span>SSL encrypted transactions</span>
            </div>
        </div>
    </div>
</section>

<!-- ── 3. CATEGORY GRID ── -->
<section class="section">
    <div class="container">
        <div class="section-header">
            <div class="section-label">Browse by Category</div>
            <h2 class="section-title">Equine Veterinary Supplies</h2>
            <p class="section-sub">Find certified, professional-grade products for every aspect of equine health and care.</p>
        </div>
        <div class="category-grid">
            <?php foreach ($categories as $cat): ?>
                <a href="/GadgetZone/pages/shop.php?cat=<?= $cat['slug'] ?>" class="category-card">
                    <div class="cat-icon"><?= $cat['icon'] ?></div>
                    <div class="cat-name"><?= htmlspecialchars($cat['name']) ?></div>
                    <div class="cat-count"><?= $cat['product_count'] ?> Items</div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ── 4. FEATURED PRODUCTS ── -->
<section class="section" style="background: rgba(255,255,255,0.01); border-top: 1px solid var(--border); border-bottom: 1px solid var(--border);">
    <div class="container">
        <div class="section-header">
            <div class="section-label">Recommended</div>
            <h2 class="section-title">Featured Products</h2>
            <p class="section-sub">Top picks trusted by veterinarians and horse owners across the region.</p>
        </div>
        
        <?php if (!empty($featured_products)): ?>
            <div class="products-grid">
                <?php foreach ($featured_products as $p): ?>
                    <div class="product-card">
                        <?php if ($p['badge']): ?>
                            <span class="badge <?= badgeClass($p['badge']) ?>"><?= htmlspecialchars($p['badge']) ?></span>
                        <?php endif; ?>
                        <div class="product-card-img">
                            <a href="/GadgetZone/pages/product.php?slug=<?= $p['slug'] ?>">
                                <img src="<?= htmlspecialchars($p['image_url']) ?>" alt="<?= htmlspecialchars($p['name']) ?>">
                            </a>
                        </div>
                        <div class="product-card-body">
                            <div class="product-cat"><?= htmlspecialchars($p['cat_name']) ?></div>
                            <a href="/GadgetZone/pages/product.php?slug=<?= $p['slug'] ?>">
                                <h3 class="product-name"><?= htmlspecialchars($p['name']) ?></h3>
                            </a>
                            <?= starRating(4.8) ?>
                            <div class="product-price">
                                <span class="price-current"><?= formatPrice($p['price']) ?></span>
                                <?php if ($p['old_price']): ?>
                                    <span class="price-old"><?= formatPrice($p['old_price']) ?></span>
                                <?php endif; ?>
                            </div>
                            <button class="btn-add-cart" data-id="<?= $p['id'] ?>">Add to Cart 🛒</button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <div class="empty-icon">🐴</div>
                <h3>No Featured Products Found</h3>
                <p>Please run the <a href="/GadgetZone/admin/run_migration.php" class="accent">Database Migration</a> to seed products.</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- ── 5. DEAL OF THE DAY ── -->
<?php if ($deal_product): ?>
<section class="section">
    <div class="container">
        <div class="deal-banner">
            <div class="deal-inner">
                <div class="deal-left">
                    <div class="deal-label">Limited Time Offer</div>
                    <h2 class="deal-title"><?= htmlspecialchars($deal_product['name']) ?></h2>
                    <p class="deal-desc"><?= htmlspecialchars($deal_product['description']) ?></p>
                    
                    <div class="deal-price">
                        <?= formatPrice($deal_product['price']) ?>
                        <?php if ($deal_product['old_price']): ?>
                            <span><?= formatPrice($deal_product['old_price']) ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="deal-timer" id="countdown">
                        <div class="timer-block">
                            <div class="timer-num" id="timer-hours">23</div>
                            <div class="timer-label">hours</div>
                        </div>
                        <div class="timer-block">
                            <div class="timer-num" id="timer-mins">45</div>
                            <div class="timer-label">mins</div>
                        </div>
                        <div class="timer-block">
                            <div class="timer-num" id="timer-secs">30</div>
                            <div class="timer-label">secs</div>
                        </div>
                    </div>
                    
                    <div class="deal-actions">
                        <button class="btn-primary btn-add-cart" data-id="<?= $deal_product['id'] ?>">Add to Cart 🛒</button>
                        <a href="/GadgetZone/pages/product.php?slug=<?= $deal_product['slug'] ?>" class="btn-outline">View Product 🔍</a>
                    </div>
                </div>
                <div class="deal-center">
                    <img src="<?= htmlspecialchars($deal_product['image_url']) ?>" alt="Deal of the Day" class="deal-img">
                </div>
                <div class="deal-right">
                    <div class="deal-rating">🏆</div>
                    <div class="deal-meta">
                        <p style="font-weight:700;color:var(--accent);margin-bottom:4px;">Vet Recommended</p>
                        <span>Verified 4.9★ Review Score</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- ── 6. NEW ARRIVALS ── -->
<section class="section" style="background: rgba(255,255,255,0.01); border-top: 1px solid var(--border); border-bottom: 1px solid var(--border);">
    <div class="container">
        <div class="section-header">
            <div class="section-label">Just Arrived</div>
            <h2 class="section-title">New Products</h2>
            <p class="section-sub">The latest additions to our veterinary and equine care collection.</p>
        </div>
        
        <?php if (!empty($new_arrivals)): ?>
            <div class="products-grid-4">
                <?php foreach ($new_arrivals as $p): ?>
                    <div class="product-card">
                        <?php if ($p['badge']): ?>
                            <span class="badge <?= badgeClass($p['badge']) ?>"><?= htmlspecialchars($p['badge']) ?></span>
                        <?php endif; ?>
                        <div class="product-card-img">
                            <a href="/GadgetZone/pages/product.php?slug=<?= $p['slug'] ?>">
                                <img src="<?= htmlspecialchars($p['image_url']) ?>" alt="<?= htmlspecialchars($p['name']) ?>">
                            </a>
                        </div>
                        <div class="product-card-body">
                            <div class="product-cat"><?= htmlspecialchars($p['cat_name']) ?></div>
                            <a href="/GadgetZone/pages/product.php?slug=<?= $p['slug'] ?>">
                                <h3 class="product-name"><?= htmlspecialchars($p['name']) ?></h3>
                            </a>
                            <?= starRating(4.6) ?>
                            <div class="product-price">
                                <span class="price-current"><?= formatPrice($p['price']) ?></span>
                                <?php if ($p['old_price']): ?>
                                    <span class="price-old"><?= formatPrice($p['old_price']) ?></span>
                                <?php endif; ?>
                            </div>
                            <button class="btn-add-cart" data-id="<?= $p['id'] ?>">Add to Cart 🛒</button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <div class="empty-icon">🐴</div>
                <h3>No Products Found</h3>
                <p>Please run the <a href="/GadgetZone/admin/run_migration.php" class="accent">Database Migration</a> to seed products.</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- ── 7. TESTIMONIALS ── -->
<section class="section">
    <div class="container">
        <div class="section-header">
            <div class="section-label">Our Community</div>
            <h2 class="section-title">What Horse Owners Say</h2>
            <p class="section-sub">Hear from veterinarians and horse owners who trust Al Asail for their equine care needs.</p>
        </div>
        <div class="testimonials-grid">
            <div class="testimonial-card">
                <div class="testimonial-stars">★★★★★</div>
                <p class="testimonial-text">"Al Asail has been our go-to supplier for all equine veterinary needs. The Penicillin G they supply is authentic and arrives quickly. Outstanding service every time!"</p>
                <div class="testimonial-author">
                    <div class="author-avatar" style="background: #8B4513;">DK</div>
                    <div>
                        <div class="author-name">Dr. Khalid Al-Rashid</div>
                        <div class="author-location">Amman, Jordan</div>
                    </div>
                </div>
            </div>
            <div class="testimonial-card">
                <div class="testimonial-stars">★★★★★</div>
                <p class="testimonial-text">"I ordered the BioTin Hoof Supplement and within 6 weeks my mare's hooves improved dramatically. Fast shipping and genuinely professional packaging."</p>
                <div class="testimonial-author">
                    <div class="author-avatar" style="background: #B8860B;">SM</div>
                    <div>
                        <div class="author-name">Sara Al-Mansouri</div>
                        <div class="author-location">Zarqa, Jordan</div>
                    </div>
                </div>
            </div>
            <div class="testimonial-card">
                <div class="testimonial-stars">★★★★★</div>
                <p class="testimonial-text">"The therapeutic horseshoes saved my racing horse from a serious hoof condition. Saved JOD 200 vs. the local farrier. Al Asail's product quality is unmatched."</p>
                <div class="testimonial-author">
                    <div class="author-avatar" style="background: #34d399;">FN</div>
                    <div>
                        <div class="author-name">Faisal Al-Nabulsi</div>
                        <div class="author-location">Irbid, Jordan</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ── 8. NEWSLETTER ── -->
<section class="newsletter-section">
    <div class="container">
        <h2>Stay Updated on Equine Health 🐎</h2>
        <p>Subscribe to receive veterinary tips, new product alerts, and exclusive offers for horse owners and professionals.</p>
        <form class="newsletter-form" onsubmit="event.preventDefault(); alert('Thank you for subscribing! You will receive equine health updates and exclusive offers.');">
            <input type="email" class="newsletter-input" placeholder="Enter your email address" required>
            <button type="submit" class="newsletter-btn">Subscribe</button>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
