<?php
require_once __DIR__ . '/../includes/functions.php';
if (isLoggedIn()) { header('Location: /GadgetZone/pages/myaccount.php'); exit; }
$pageTitle = 'Register — GadgetZone';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fn    = trim($_POST['first_name'] ?? '');
    $ln    = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';
    $conf  = $_POST['confirm_password'] ?? '';

    if (!$fn) $errors[] = 'First name is required.';
    if (!$ln) $errors[] = 'Last name is required.';
    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    if (strlen($pass) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($pass !== $conf) $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        $e = $conn->real_escape_string($email);
        $exists = $conn->query("SELECT id FROM users WHERE email='$e'")->num_rows;
        if ($exists) {
            $errors[] = 'Email is already registered. <a href="/GadgetZone/pages/login.php">Log in instead →</a>';
        } else {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $fnQ  = $conn->real_escape_string($fn);
            $lnQ  = $conn->real_escape_string($ln);
            $conn->query("INSERT INTO users (first_name, last_name, email, password) VALUES ('$fnQ','$lnQ','$e','$hash')");
            $_SESSION['user_id'] = $conn->insert_id;
            header('Location: /GadgetZone/pages/myaccount.php');
            exit;
        }
    }
}
require_once __DIR__ . '/../includes/header.php';
?>

<div class="auth-page">
    <div class="auth-card fade-in">
        <h1 class="auth-title">Create Account 🚀</h1>
        <p class="auth-sub">Join GadgetZone and start shopping</p>
        <?php if (!empty($errors)): ?><div class="alert alert-error"><?= implode('<br>', $errors) ?></div><?php endif; ?>
        <form method="POST" class="auth-form">
            <div class="form-grid" style="gap:12px">
                <div class="form-group">
                    <label class="form-label">First Name</label>
                    <input type="text" name="first_name" class="form-input" value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Last Name</label>
                    <input type="text" name="last_name" class="form-input" value="<?= htmlspecialchars($_POST['last_name'] ?? '') ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-input" placeholder="you@example.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label">Password (min 6 characters)</label>
                <input type="password" name="password" class="form-input" placeholder="••••••••" required>
            </div>
            <div class="form-group">
                <label class="form-label">Confirm Password</label>
                <input type="password" name="confirm_password" class="form-input" placeholder="••••••••" required>
            </div>
            <button type="submit" class="btn-primary" style="width:100%;justify-content:center;padding:14px;font-size:16px">🚀 Create Account</button>
        </form>
        <div class="auth-footer">Already have an account? <a href="/GadgetZone/pages/login.php">Log in →</a></div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
