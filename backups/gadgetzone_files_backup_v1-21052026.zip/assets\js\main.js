/* Al Asail Equine — Main JS */
const _BASE = window.location.pathname.toLowerCase().startsWith('/gadgetzone') ? '/GadgetZone' : (window.location.pathname.startsWith('/gadget') ? '/gadget' : '');

/* ── Hamburger ───────────────────────────────── */
const hamburger = document.getElementById('hamburger');
const mobileNav = document.getElementById('mobileNav');
if (hamburger && mobileNav) {
    hamburger.addEventListener('click', () => mobileNav.classList.toggle('open'));
}

/* ── Cart Popup ──────────────────────────────── */
function showCartPopup() {
    const overlay = document.getElementById('cartPopupOverlay');
    if (!overlay) return;
    overlay.classList.add('active');
    // Trap focus inside popup
    const popup = document.getElementById('cartPopup');
    if (popup) popup.focus();
}

function hideCartPopup() {
    const overlay = document.getElementById('cartPopupOverlay');
    if (overlay) overlay.classList.remove('active');
}

// Close button
document.addEventListener('DOMContentLoaded', () => {
    const closeBtn = document.getElementById('cartPopupClose');
    if (closeBtn) closeBtn.addEventListener('click', hideCartPopup);

    const overlay = document.getElementById('cartPopupOverlay');
    if (overlay) {
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) hideCartPopup();
        });
    }

    // ESC key closes popup
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') hideCartPopup();
    });
});

/* ── Add to Cart ─────────────────────────────── */
document.addEventListener('click', async (e) => {
    const btn = e.target.closest('.btn-add-cart');
    if (!btn) return;
    e.preventDefault();
    const productId = btn.dataset.id;
    if (!productId) return;
    const qty = parseInt(document.getElementById('detail-qty')?.value || 1);
    btn.disabled = true;
    btn.textContent = 'Adding...';
    try {
        const res = await fetch(_BASE + '/pages/cart_action.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=add&product_id=${productId}&qty=${qty}`
        });
        const data = await res.json();
        if (data.success) {
            updateCartBadge(data.cart_count);
            btn.textContent = '✓ Added!';
            btn.style.background = '#10b981';
            // Show popup
            showCartPopup();
            setTimeout(() => {
                btn.textContent = 'Add to Cart 🛒';
                btn.style.background = '';
                btn.disabled = false;
            }, 2000);
        } else {
            btn.textContent = 'Error';
            btn.disabled = false;
        }
    } catch {
        btn.textContent = 'Add to Cart 🛒';
        btn.disabled = false;
    }
});

/* ── Cart Badge ──────────────────────────────── */
function updateCartBadge(count) {
    const badge = document.querySelector('.cart-badge');
    if (!badge) return;
    badge.textContent = count;
    badge.style.display = count > 0 ? 'flex' : 'none';
}

/* ── Cart Quantity ───────────────────────────── */
document.addEventListener('click', async (e) => {
    const btn = e.target.closest('.qty-btn');
    if (!btn) return;
    const row = btn.closest('tr');
    if (!row) return;
    const input = row.querySelector('.qty-input');
    if (!input) return;
    let qty = parseInt(input.value);
    if (btn.dataset.dir === 'up') qty++;
    if (btn.dataset.dir === 'down') qty--;
    if (qty < 1) qty = 1;
    if (qty > 99) qty = 99;
    input.value = qty;
    await updateCartItem(input.dataset.id, qty, row);
});

document.addEventListener('change', async (e) => {
    if (!e.target.classList.contains('qty-input')) return;
    const row = e.target.closest('tr');
    let qty = parseInt(e.target.value);
    if (isNaN(qty) || qty < 1) qty = 1;
    if (qty > 99) qty = 99;
    e.target.value = qty;
    await updateCartItem(e.target.dataset.id, qty, row);
});

async function updateCartItem(id, qty, row) {
    try {
        const res = await fetch(_BASE + '/pages/cart_action.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=update&product_id=${id}&qty=${qty}`
        });
        const data = await res.json();
        if (data.success) {
            updateCartBadge(data.cart_count);
            const subtotalEl = row.querySelector('.cart-subtotal');
            if (subtotalEl && data.item_subtotal) subtotalEl.textContent = data.item_subtotal;
            const totalEl = document.querySelector('.cart-total-display');
            if (totalEl && data.formatted_total) totalEl.textContent = data.formatted_total;
            const shippingEl = document.querySelector('.shipping-display');
            if (shippingEl && data.shipping !== undefined) shippingEl.textContent = data.shipping;
            const shippingNote = document.querySelector('.shipping-note');
            if (shippingNote) shippingNote.textContent = data.shipping_note || '';
        }
    } catch {}
}

/* ── Cart Remove (AJAX intercept) ── */
document.addEventListener('submit', async (e) => {
    if (!e.target.classList.contains('remove-form')) return;
    e.preventDefault();
    const form = e.target;
    const row = form.closest('tr');
    const id = form.querySelector('[name=remove_id]').value;
    try {
        const res = await fetch(_BASE + '/pages/cart_action.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=remove&product_id=${id}`
        });
        const data = await res.json();
        if (data.success) {
            row.style.transition = 'opacity 0.3s, transform 0.3s';
            row.style.opacity = '0';
            row.style.transform = 'translateX(20px)';
            setTimeout(() => {
                row.remove();
                updateCartBadge(data.cart_count);
                const totalEl = document.querySelector('.cart-total-display');
                if (totalEl && data.formatted_total) totalEl.textContent = data.formatted_total;
                if (data.cart_count === 0) location.reload();
            }, 320);
        }
    } catch {
        form.submit();
    }
});

/* ── Payment method selection ────────────────── */
document.querySelectorAll('.payment-option').forEach(opt => {
    opt.addEventListener('click', () => {
        document.querySelectorAll('.payment-option').forEach(o => o.classList.remove('selected'));
        opt.classList.add('selected');
        opt.querySelector('input[type=radio]').checked = true;
    });
});

/* ── Countdown Timer ─────────────────────────── */
const timer = document.getElementById('countdown');
if (timer) {
    const end = new Date().getTime() + (23 * 3600 + 45 * 60 + 30) * 1000;
    setInterval(() => {
        const now = new Date().getTime();
        const diff = end - now;
        if (diff <= 0) return;
        const h = Math.floor(diff / 3600000);
        const m = Math.floor((diff % 3600000) / 60000);
        const s = Math.floor((diff % 60000) / 1000);
        ['hours','mins','secs'].forEach((k, i) => {
            const el = document.getElementById('timer-' + k);
            if (el) el.textContent = [h,m,s][i].toString().padStart(2,'0');
        });
    }, 1000);
}

/* ── Scroll animations ───────────────────────── */
if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animationPlayState = 'running';
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });
    document.querySelectorAll('.product-card, .category-card, .testimonial-card').forEach(el => {
        el.style.animation = 'fadeIn 0.5s ease both';
        el.style.animationPlayState = 'paused';
        observer.observe(el);
    });
}

/* ── Price range slider ──────────────────────── */
const priceRange = document.getElementById('priceRange');
const priceLabel = document.getElementById('priceLabel');
if (priceRange && priceLabel) {
    priceRange.addEventListener('input', () => {
        priceLabel.textContent = parseInt(priceRange.value).toLocaleString();
    });
}

/* ── Account tabs ────────────────────────────── */
document.querySelectorAll('[data-tab]').forEach(link => {
    link.addEventListener('click', (e) => {
        const tab = link.dataset.tab;
        if (!tab) return;
        const url = new URL(window.location);
        url.searchParams.set('tab', tab);
        window.location = url.toString();
    });
});

/* ── Admin subcategory dropdown ──────────────── */
const adminCatSelect = document.getElementById('modal_cat');
const adminSubcatSelect = document.getElementById('modal_subcat');
if (adminCatSelect && adminSubcatSelect) {
    adminCatSelect.addEventListener('change', async function() {
        const catId = this.value;
        adminSubcatSelect.innerHTML = '<option value="">— None —</option>';
        if (!catId) return;
        try {
            const res = await fetch(_BASE + '/admin/get_subcategories.php?cat_id=' + catId);
            const data = await res.json();
            data.forEach(s => {
                const opt = document.createElement('option');
                opt.value = s.id;
                opt.textContent = s.name;
                adminSubcatSelect.appendChild(opt);
            });
        } catch(e) { console.error('Subcategory fetch error', e); }
    });
}
