<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/currency.php';

/* ── Auth ─────────────────────────────────────────────── */
function isLoggedIn(): bool {
    return !empty($_SESSION['user_id']);
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        $redirect = urlencode($_SERVER['REQUEST_URI']);
        header("Location: /GadgetZone/pages/login.php?redirect=$redirect");
        exit;
    }
}

function getCurrentUser(): ?array {
    global $conn;
    if (!isLoggedIn()) return null;
    $id = (int)$_SESSION['user_id'];
    $r = $conn->query("SELECT * FROM users WHERE id=$id");
    return $r && $r->num_rows ? $r->fetch_assoc() : null;
}

function isAdmin(): bool {
    $u = getCurrentUser();
    return $u && in_array($u['role'], ['admin','super_admin']);
}

/* ── Cart ─────────────────────────────────────────────── */
function getCart(): array {
    return $_SESSION['cart'] ?? [];
}

function addToCart(int $id, int $qty = 1): void {
    if (!isset($_SESSION['cart'][$id])) {
        $_SESSION['cart'][$id] = 0;
    }
    $_SESSION['cart'][$id] += $qty;
}

function updateCartQty(int $id, int $qty): void {
    if ($qty <= 0) {
        unset($_SESSION['cart'][$id]);
    } else {
        $_SESSION['cart'][$id] = $qty;
    }
}

function removeFromCart(int $id): void {
    unset($_SESSION['cart'][$id]);
}

function getCartCount(): int {
    return array_sum($_SESSION['cart'] ?? []);
}

function getCartTotal(): float {
    global $conn;
    $cart = getCart();
    if (empty($cart)) return 0.0;
    $ids = implode(',', array_map('intval', array_keys($cart)));
    $res = $conn->query("SELECT id, price FROM products WHERE id IN ($ids)");
    $total = 0.0;
    while ($row = $res->fetch_assoc()) {
        $total += $row['price'] * ($cart[$row['id']] ?? 0);
    }
    return $total;
}

function getCartItems(): array {
    global $conn;
    $cart = getCart();
    if (empty($cart)) return [];
    $ids = implode(',', array_map('intval', array_keys($cart)));
    $res = $conn->query("SELECT p.*, c.name AS cat_name FROM products p
        JOIN categories c ON c.id=p.category_id WHERE p.id IN ($ids)");
    $items = [];
    while ($row = $res->fetch_assoc()) {
        $row['qty'] = $cart[$row['id']];
        $items[] = $row;
    }
    return $items;
}

/* ── Utilities ────────────────────────────────────────── */
function sanitize(string $data): string {
    global $conn;
    return htmlspecialchars(strip_tags(trim($conn->real_escape_string($data))));
}

function generateOrderNumber(): string {
    return 'EVS-' . strtoupper(uniqid());
}

function badgeClass(string $badge): string {
    return match($badge) {
        'HOT'  => 'badge-hot',
        'NEW'  => 'badge-new',
        'SALE' => 'badge-sale',
        default => '',
    };
}

function starRating(float $rating = 4.5): string {
    $html = '<div class="stars">';
    for ($i = 1; $i <= 5; $i++) {
        $html .= $i <= $rating ? '★' : ($i - 0.5 <= $rating ? '½' : '☆');
    }
    $html .= '</div>';
    return $html;
}

function statusBadge(string $status): string {
    $map = [
        'pending'    => 'badge-pending',
        'processing' => 'badge-processing',
        'shipped'    => 'badge-shipped',
        'delivered'  => 'badge-delivered',
        'cancelled'  => 'badge-cancelled',
    ];
    $cls = $map[$status] ?? '';
    return '<span class="status-badge '.$cls.'">'.ucfirst($status).'</span>';
}

function getCategories(): array {
    global $conn;
    $res = $conn->query("
        SELECT c.*, 
               (SELECT COUNT(*) FROM products p WHERE p.category_id=c.id) AS product_count 
        FROM categories c 
        ORDER BY c.order_num ASC, c.id ASC
    ");
    $cats = [];
    while ($r = $res->fetch_assoc()) $cats[] = $r;
    return $cats;
}

function getSubcategories(int $categoryId): array {
    global $conn;
    $res = $conn->query("
        SELECT s.*, 
               (SELECT COUNT(*) FROM products p WHERE p.subcategory_id=s.id) AS product_count 
        FROM subcategories s 
        WHERE s.category_id=$categoryId 
        ORDER BY s.order_num ASC, s.id ASC
    ");
    $subs = [];
    while ($r = $res->fetch_assoc()) $subs[] = $r;
    return $subs;
}

function getAllSubcategories(): array {
    global $conn;
    $res = $conn->query("
        SELECT s.*, c.name AS cat_name,
               (SELECT COUNT(*) FROM products p WHERE p.subcategory_id=s.id) AS product_count
        FROM subcategories s
        JOIN categories c ON c.id = s.category_id
        ORDER BY c.order_num ASC, s.order_num ASC
    ");
    $subs = [];
    while ($r = $res->fetch_assoc()) $subs[] = $r;
    return $subs;
}
