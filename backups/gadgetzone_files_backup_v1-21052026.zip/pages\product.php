<?php
require_once __DIR__ . '/../includes/functions.php';
$slug = $conn->real_escape_string($_GET['slug'] ?? '');
$product = $conn->query("SELECT p.*, c.name AS cat_name, c.slug AS cat_slug FROM products p JOIN categories c ON c.id=p.category_id WHERE p.slug='$slug'")->fetch_assoc();
if (!$product) { header('Location: /GadgetZone/pages/shop.php'); exit; }

$pageTitle = htmlspecialchars($product['name']) . ' — GadgetZone';

// Related products
$catId = (int)$product['category_id'];
$pid   = (int)$product['id'];
$related = $conn->query("SELECT p.*, c.name AS cat_name FROM products p JOIN categories c ON c.id=p.category_id WHERE p.category_id=$catId AND p.id!=$pid LIMIT 4");
require_once __DIR__ . '/../includes/header.php';
?>

<div class="container">
    <div class="breadcrumb">
        <a href="/GadgetZone/index.php">Home</a> <span>›</span>
        <a href="/GadgetZone/pages/shop.php">Shop</a> <span>›</span>
        <a href="/GadgetZone/pages/shop.php?cat=<?= $product['cat_slug'] ?>"><?= htmlspecialchars($product['cat_name']) ?></a>
        <span>›</span> <?= htmlspecialchars($product['name']) ?>
    </div>

    <div class="product-detail">
        <div class="product-detail-img">
            <?php if ($product['badge']): ?><span class="badge <?= badgeClass($product['badge']) ?>" style="position:static;display:inline-block;margin-bottom:12px"><?= $product['badge'] ?></span><?php endif; ?>
            <img src="<?= htmlspecialchars($product['image_url']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
        </div>
        <div class="product-detail-info">
            <div class="product-cat" style="font-size:13px;margin-bottom:8px"><?= htmlspecialchars($product['cat_name']) ?></div>
            <h1 class="product-detail-title"><?= htmlspecialchars($product['name']) ?></h1>
            <div class="stars" style="font-size:18px;margin-bottom:12px">★★★★★ <span style="font-size:13px;color:var(--text2);">(4.9 · 128 reviews)</span></div>
            <div class="product-detail-price"><?= formatPrice($product['price']) ?></div>
            <?php if ($product['old_price']): ?>
            <div class="product-detail-old"><?= formatPrice($product['old_price']) ?>
                <span style="font-size:13px;background:var(--accent);color:#000;padding:2px 8px;border-radius:5px;margin-left:8px;font-style:normal">
                    <?= round((1 - $product['price']/$product['old_price'])*100) ?>% OFF
                </span>
            </div>
            <?php endif; ?>
            <p class="product-detail-desc"><?= nl2br(htmlspecialchars($product['description'])) ?></p>
            <div class="stock-info">✅ In Stock — <?= $product['stock'] ?> units available</div>
            <div class="qty-row">
                <label style="font-size:13px;color:var(--text2)">Quantity:</label>
                <div class="qty-control">
                    <button type="button" class="qty-btn" onclick="let i=document.getElementById('detail-qty');i.value=Math.max(1,+i.value-1)">−</button>
                    <input type="number" id="detail-qty" class="qty-input" value="1" min="1" max="<?= $product['stock'] ?>">
                    <button type="button" class="qty-btn" onclick="let i=document.getElementById('detail-qty');i.value=Math.min(<?= $product['stock'] ?>,+i.value+1)">+</button>
                </div>
            </div>
            <div style="display:flex;gap:12px;flex-wrap:wrap">
                <button class="btn-primary btn-add-cart" data-id="<?= $product['id'] ?>" style="flex:1;min-width:180px">🛒 Add to Cart</button>
                <a href="/GadgetZone/pages/cart.php" class="btn-outline" style="flex:1;min-width:180px;text-align:center">View Cart →</a>
            </div>
            <div style="margin-top:24px;display:flex;flex-direction:column;gap:8px">
                <div style="display:flex;gap:10px;font-size:13px;color:var(--text2)"><span>🚚</span> Free delivery on orders over <?= formatPrice(5000) ?></div>
                <div style="display:flex;gap:10px;font-size:13px;color:var(--text2)"><span>↩️</span> 7-day hassle-free returns</div>
                <div style="display:flex;gap:10px;font-size:13px;color:var(--text2)"><span>🛡️</span> 2-year manufacturer warranty</div>
                <div style="display:flex;gap:10px;font-size:13px;color:var(--text2)"><span>🔒</span> Secure, encrypted payment</div>
            </div>
        </div>
    </div>
</div>

<!-- RELATED PRODUCTS -->
<?php if ($related->num_rows): ?>
<section class="section" style="padding-top:0">
    <div class="container">
        <div class="section-header">
            <div class="section-label">You Might Also Like</div>
            <h2 class="section-title">Related <span class="accent">Products</span></h2>
        </div>
        <div class="products-grid-4">
            <?php while ($p = $related->fetch_assoc()): ?>
            <div class="product-card">
                <?php if ($p['badge']): ?><span class="badge <?= badgeClass($p['badge']) ?>"><?= $p['badge'] ?></span><?php endif; ?>
                <a href="/GadgetZone/pages/product.php?slug=<?= $p['slug'] ?>">
                    <div class="product-card-img">
                        <img src="<?= htmlspecialchars($p['image_url']) ?>" alt="<?= htmlspecialchars($p['name']) ?>" loading="lazy">
                    </div>
                </a>
                <div class="product-card-body">
                    <div class="product-cat"><?= htmlspecialchars($p['cat_name']) ?></div>
                    <a href="/GadgetZone/pages/product.php?slug=<?= $p['slug'] ?>">
                        <div class="product-name"><?= htmlspecialchars($p['name']) ?></div>
                    </a>
                    <div class="stars">★★★★★</div>
                    <div class="product-price">
                        <span class="price-current"><?= formatPrice($p['price']) ?></span>
                        <?php if ($p['old_price']): ?><span class="price-old"><?= formatPrice($p['old_price']) ?></span><?php endif; ?>
                    </div>
                    <button class="btn-add-cart" data-id="<?= $p['id'] ?>">Add to Cart 🛒</button>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
