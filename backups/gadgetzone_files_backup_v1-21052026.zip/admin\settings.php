<?php
$pageTitle = 'Settings — Admin';
require_once __DIR__ . '/layout.php';

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $currency = $conn->real_escape_string($_POST['active_currency'] ?? 'BDT');
    $pk       = $conn->real_escape_string(trim($_POST['stripe_publishable_key'] ?? ''));
    $sk       = $conn->real_escape_string(trim($_POST['stripe_secret_key'] ?? ''));
    $wh       = $conn->real_escape_string(trim($_POST['stripe_webhook_secret'] ?? ''));

    $settings = [
        'active_currency'        => $currency,
        'stripe_publishable_key' => $pk,
        'stripe_secret_key'      => $sk,
        'stripe_webhook_secret'  => $wh,
    ];
    foreach ($settings as $k => $v) {
        $conn->query("INSERT INTO settings (setting_key,setting_value) VALUES ('$k','$v') ON DUPLICATE KEY UPDATE setting_value='$v'");
    }
    // Invalidate session cache
    unset($_SESSION['active_currency_data']);
    $msg = 'Settings saved successfully!';
}

// Load settings
$settingsData = [];
$res = $conn->query("SELECT * FROM settings");
while ($r = $res->fetch_assoc()) $settingsData[$r['setting_key']] = $r['setting_value'];

$activeCur = $settingsData['active_currency'] ?? 'BDT';
require_once __DIR__ . '/../includes/currency.php';
?>

<div class="admin-header">
    <div>
        <div class="admin-title">Settings</div>
        <div class="admin-subtitle">Configure currency and payment options</div>
    </div>
</div>

<?php if ($msg): ?><div class="alert alert-success">✅ <?= htmlspecialchars($msg) ?></div><?php endif; ?>

<form method="POST">
    <input type="hidden" name="active_currency" id="activeCurrencyInput" value="<?= htmlspecialchars($activeCur) ?>">

    <!-- Currency -->
    <div class="admin-card" style="margin-bottom:24px">
        <div class="admin-card-header">
            <div class="admin-card-title">🌐 Active Currency</div>
            <div style="font-size:13px;color:var(--text2)">Current: <strong style="color:var(--accent)"><?= $activeCur ?></strong></div>
        </div>
        <div class="admin-card-body">
            <div class="currency-grid">
                <?php foreach (CURRENCIES as $code => $cur): ?>
                <div class="currency-card <?= $code===$activeCur?'selected':'' ?>" data-code="<?= $code ?>">
                    <div class="currency-code"><?= $code ?></div>
                    <div class="currency-symbol"><?= $cur['symbol'] ?></div>
                    <div class="currency-name"><?= $cur['name'] ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Stripe -->
    <div class="admin-card" style="margin-bottom:24px">
        <div class="admin-card-header">
            <div class="admin-card-title">💳 Stripe Payment</div>
        </div>
        <div class="admin-card-body">
            <div class="alert alert-success" style="margin-bottom:16px">
                Get your keys from <a href="https://dashboard.stripe.com/test/apikeys" target="_blank" style="color:var(--accent)">dashboard.stripe.com</a> → Developers → API Keys (enable Test Mode first).
            </div>
            <div class="form-grid-2" style="gap:16px">
                <div class="form-group">
                    <label class="form-label">Publishable Key (pk_test_...)</label>
                    <input type="text" name="stripe_publishable_key" class="form-input" value="<?= htmlspecialchars($settingsData['stripe_publishable_key'] ?? '') ?>" placeholder="pk_test_...">
                </div>
                <div class="form-group">
                    <label class="form-label">Secret Key (sk_test_...)</label>
                    <input type="password" name="stripe_secret_key" class="form-input" value="<?= htmlspecialchars($settingsData['stripe_secret_key'] ?? '') ?>" placeholder="sk_test_...">
                </div>
                <div class="form-group">
                    <label class="form-label">Webhook Secret (optional)</label>
                    <input type="text" name="stripe_webhook_secret" class="form-input" value="<?= htmlspecialchars($settingsData['stripe_webhook_secret'] ?? '') ?>" placeholder="whsec_...">
                </div>
            </div>
            <div style="margin-top:12px;padding:14px;background:var(--surface2);border-radius:var(--r);font-size:13px;color:var(--text2)">
                <strong style="color:var(--text)">Test Cards:</strong>
                Visa: 4242 4242 4242 4242 &nbsp;|&nbsp; MC: 5555 5555 5555 4444 &nbsp;|&nbsp; Declined: 4000 0000 0000 0002 (Exp: 12/25, CVC: 123)
            </div>
        </div>
    </div>

    <button type="submit" class="btn-admin btn-admin-primary" style="padding:12px 32px;font-size:15px">Save All Settings</button>
</form>

<?php require_once __DIR__ . '/footer.php'; ?>
