<?php
require_once __DIR__ . '/functions.php';
$cartCount = getCartCount();
$user = getCurrentUser();
$categories = getCategories();
$currentPath = $_SERVER['REQUEST_URI'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? 'Al Asail — Equine Veterinary Supplies' ?></title>
    <meta name="description" content="Al Asail Equine Veterinary Supplies — Professional horse medicines, supplements, horseshoes, and veterinary products in Jordan.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700;800&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/GadgetZone/assets/css/style.css?v=<?= filemtime(__DIR__.'/../assets/css/style.css') ?>">
    <?= $extraHead ?? '' ?>
</head>
<body>

<header class="site-header">
    <div class="header-inner container">
        <a href="/GadgetZone/index.php" class="logo">
            <img src="/GadgetZone/assets/images/logo.png" alt="Al Asail Equine Veterinary Supplies" class="site-logo-img">
        </a>

        <nav class="main-nav">
            <a href="/GadgetZone/index.php" class="nav-link">Home</a>
            <a href="/GadgetZone/pages/shop.php" class="nav-link">Shop</a>
            <div class="nav-dropdown">
                <span class="nav-link">Categories ▾</span>
                <div class="dropdown-menu">
                    <?php foreach ($categories as $cat): ?>
                    <a href="/GadgetZone/pages/shop.php?cat=<?= $cat['slug'] ?>" class="dropdown-item">
                        <span><?= $cat['icon'] ?></span> <?= htmlspecialchars($cat['name']) ?>
                        <span class="dropdown-count"><?= $cat['product_count'] ?></span>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
            <a href="/GadgetZone/pages/shop.php?badge=SALE" class="nav-link accent">Offers</a>
        </nav>

        <div class="header-search">
            <form action="/GadgetZone/pages/shop.php" method="GET">
                <input type="text" name="search" placeholder="Search veterinary products..." class="search-input" value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
                <button type="submit" class="search-btn">🔍</button>
            </form>
        </div>

        <div class="header-actions">
            <?php if (isLoggedIn()): ?>
            <a href="/GadgetZone/pages/myaccount.php" class="btn-icon" title="My Account">
                <span class="avatar-tiny"><?= strtoupper(substr($user['first_name'],0,1).substr($user['last_name'],0,1)) ?></span>
            </a>
            <?php if (isAdmin()): ?>
            <a href="/GadgetZone/admin/index.php" class="btn-icon" title="Admin">⚙️</a>
            <?php endif; ?>
            <?php else: ?>
            <a href="/GadgetZone/pages/login.php" class="btn-outline-sm">Login</a>
            <?php endif; ?>

            <a href="/GadgetZone/pages/cart.php" class="cart-btn">
                🛒
                <span class="cart-badge" style="<?= $cartCount === 0 ? 'display:none' : '' ?>"><?= $cartCount ?></span>
            </a>
        </div>

        <button class="hamburger" id="hamburger" aria-label="Toggle menu">☰</button>
    </div>

    <div class="mobile-nav" id="mobileNav">
        <a href="/GadgetZone/index.php">Home</a>
        <a href="/GadgetZone/pages/shop.php">Shop</a>
        <?php foreach ($categories as $cat): ?>
        <a href="/GadgetZone/pages/shop.php?cat=<?= $cat['slug'] ?>"><?= $cat['icon'] ?> <?= htmlspecialchars($cat['name']) ?></a>
        <?php endforeach; ?>
        <a href="/GadgetZone/pages/shop.php?badge=SALE" class="accent">🔥 Offers</a>
        <?php if (isLoggedIn()): ?>
        <a href="/GadgetZone/pages/myaccount.php">👤 My Account</a>
        <a href="/GadgetZone/pages/logout.php">🚪 Logout</a>
        <?php else: ?>
        <a href="/GadgetZone/pages/login.php">🔐 Login</a>
        <a href="/GadgetZone/pages/register.php">📝 Register</a>
        <?php endif; ?>
    </div>
</header>

<main>
