<?php
require_once __DIR__ . '/../includes/functions.php';

// Server-side remove fallback
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_id'])) {
    removeFromCart((int)$_POST['remove_id']);
    header('Location: /GadgetZone/pages/cart.php');
    exit;
}

$pageTitle = 'Shopping Cart — Al Asail Equine';
$cartItems = getCartItems();
$cartTotal = getCartTotal();
$shipping  = $cartTotal > 5000 ? 0 : ($cartTotal > 0 ? 150 : 0);
$grand     = $cartTotal + $shipping;
$itemCount = getCartCount();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container" style="padding-top:24px">
    <div class="breadcrumb">
        <a href="/GadgetZone/index.php">Home</a> <span>›</span> Shopping Cart
    </div>
    <div class="page-hero">
        <h1 class="page-hero-title">Shopping Cart <span class="accent">(<?= $itemCount ?>)</span></h1>
    </div>

    <?php if (empty($cartItems)): ?>
    <div class="cart-empty">
        <div class="cart-empty-icon">🛍️</div>
        <h2 style="font-size:26px;margin-bottom:12px">Your cart is empty</h2>
        <p style="color:var(--text2);margin-bottom:24px">You haven't added any veterinary products yet. Browse our equine health catalogue!</p>
        <a href="/GadgetZone/pages/shop.php" class="btn-primary">Start Shopping 🐎</a>
    </div>
    <?php else: ?>
    <div class="cart-layout">
        <div>
            <table class="cart-table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Subtotal</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cartItems as $item): ?>
                    <tr>
                        <td>
                            <div class="cart-product">
                                <img src="<?= htmlspecialchars($item['image_url']) ?>" alt="" class="cart-thumb">
                                <div>
                                    <div class="cart-product-name"><?= htmlspecialchars($item['name']) ?></div>
                                    <div class="cart-product-cat"><?= htmlspecialchars($item['cat_name']) ?></div>
                                </div>
                            </div>
                        </td>
                        <td><span class="cart-price"><?= formatPrice($item['price']) ?></span></td>
                        <td>
                            <div class="qty-control">
                                <button type="button" class="qty-btn" data-dir="down">−</button>
                                <input type="number" class="qty-input" data-id="<?= $item['id'] ?>" value="<?= $item['qty'] ?>" min="1" max="99">
                                <button type="button" class="qty-btn" data-dir="up">+</button>
                            </div>
                        </td>
                        <td><span class="cart-subtotal cart-price"><?= formatPrice($item['price'] * $item['qty']) ?></span></td>
                        <td>
                            <form method="POST" class="remove-form">
                                <input type="hidden" name="remove_id" value="<?= $item['id'] ?>">
                                <button type="submit" class="remove-btn" title="Remove">×</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div style="margin-top:16px">
                <a href="/GadgetZone/pages/shop.php" class="btn-outline">← Continue Shopping</a>
            </div>
        </div>

        <!-- ORDER SUMMARY -->
        <div class="order-summary">
            <div class="summary-title">Order Summary</div>
            <div class="summary-row">
                <span>Subtotal (<?= $itemCount ?> items)</span>
                <span><?= formatPrice($cartTotal) ?></span>
            </div>
            <div class="summary-row">
                <span>Shipping</span>
                <span class="shipping-display"><?= $shipping > 0 ? formatPrice($shipping) : '<span style="color:#34d399">Free</span>' ?></span>
            </div>
            <?php if ($shipping > 0): ?>
            <p class="shipping-note">Add <?= formatPrice(5000 - $cartTotal) ?> more for free shipping!</p>
            <?php else: ?>
            <p class="shipping-note">🎉 You have free shipping!</p>
            <?php endif; ?>
            <div class="divider"></div>
            <div class="summary-row total">
                <span>Total</span>
                <span class="cart-total-display"><?= formatPrice($grand) ?></span>
            </div>
            <div class="coupon-row">
                <input type="text" class="coupon-input" placeholder="Coupon code">
                <button class="btn-sm">Apply</button>
            </div>
            <a href="/GadgetZone/pages/checkout.php" class="btn-primary" style="width:100%;justify-content:center;padding:14px;font-size:16px;margin-top:8px">
                Proceed to Checkout →
            </a>
            <div class="payment-icons-row">
                <span class="pay-icon">VISA</span>
                <span class="pay-icon">MC</span>
                <span class="pay-icon">PayPal</span>
                <span class="pay-icon">Stripe</span>
            </div>
            <div class="security-msg">🔒 Secure Checkout Guaranteed</div>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
