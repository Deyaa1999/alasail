<?php
require_once __DIR__ . '/../includes/functions.php';
if (isLoggedIn()) { header('Location: /GadgetZone/pages/myaccount.php'); exit; }
$pageTitle = 'Login — GadgetZone';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';
    if ($email && $pass) {
        $e   = $conn->real_escape_string($email);
        $res = $conn->query("SELECT * FROM users WHERE email='$e'");
        if ($res === false) {
            // Query failed — likely the database hasn't been set up yet
            $error = 'Database error: ' . htmlspecialchars($conn->error) . '. Please run the <a href="/GadgetZone/import.php">Database Installer</a> first.';
        } else {
            $user = $res->fetch_assoc();
            if ($user && password_verify($pass, $user['password'])) {
                $_SESSION['user_id']   = $user['id'];
                $_SESSION['user_role'] = $user['role'];
                $redirect = $_GET['redirect'] ?? '/GadgetZone/pages/myaccount.php';
                header("Location: $redirect");
                exit;
            } else {
                $error = 'Invalid email or password.';
            }
        }
    } else {
        $error = 'Please fill in all fields.';
    }
}
require_once __DIR__ . '/../includes/header.php';
?>

<div class="auth-page">
    <div class="auth-card fade-in">
        <h1 class="auth-title">Welcome Back 👋</h1>
        <p class="auth-sub">Log in to your GadgetZone account</p>
        <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <form method="POST" class="auth-form">
            <div class="form-group">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-input" placeholder="you@example.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-input" placeholder="••••••••" required>
            </div>
            <button type="submit" class="btn-primary" style="width:100%;justify-content:center;padding:14px;font-size:16px">🔒 Log In</button>
        </form>
        <div class="auth-footer">Don't have an account? <a href="/GadgetZone/pages/register.php">Create one →</a></div>
        <div style="margin-top:12px;text-align:center;font-size:12px;color:var(--text3)">
            Admin demo: admin@gadgetzone.com / Admin@1234
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
