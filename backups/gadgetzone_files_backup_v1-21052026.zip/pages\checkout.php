<?php
require_once __DIR__ . '/../includes/functions.php';
$pageTitle = 'Checkout — Al Asail Equine';

$cartItems = getCartItems();
if (empty($cartItems)) { header('Location: /GadgetZone/pages/cart.php'); exit; }

$cartTotal = getCartTotal();
$shipping  = $cartTotal > 5000 ? 0 : 150;
$grand     = $cartTotal + $shipping;
$user      = getCurrentUser();
$errors    = [];
$success   = false;

// Check Stripe keys
$stripeRes = $conn->query("SELECT setting_value FROM settings WHERE setting_key='stripe_publishable_key'");
$stripePk  = $stripeRes ? $stripeRes->fetch_assoc()['setting_value'] ?? '' : '';
$stripeEnabled = str_starts_with((string)$stripePk, 'pk_');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['stripe_redirect'])) {
    $firstName = sanitize($_POST['first_name'] ?? '');
    $lastName  = sanitize($_POST['last_name'] ?? '');
    $email     = sanitize($_POST['email'] ?? '');
    $phone     = sanitize($_POST['phone'] ?? '');
    $address   = sanitize($_POST['address'] ?? '');
    $city      = sanitize($_POST['city'] ?? '');
    $notes     = sanitize($_POST['notes'] ?? '');
    $payment   = sanitize($_POST['payment_method'] ?? 'cod');

    if (!$firstName) $errors[] = 'First name is required.';
    if (!$lastName)  $errors[] = 'Last name is required.';
    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    if (!$phone) $errors[] = 'Phone number is required.';
    if (!$address) $errors[] = 'Street address is required.';
    if (!$city)    $errors[] = 'City is required.';

    if (empty($errors)) {
        $orderNum    = generateOrderNumber();
        $userId      = $user ? $user['id'] : 'NULL';
        $shippingAddr = "$firstName $lastName, $address, $city — Phone: $phone";
        $notesQ      = $conn->real_escape_string($notes);
        $addrQ       = $conn->real_escape_string($shippingAddr);

        $conn->query("INSERT INTO orders (user_id, order_number, total_amount, status, payment_method, shipping_address, notes)
            VALUES ($userId, '$orderNum', $grand, 'pending', '$payment', '$addrQ', '$notesQ')");
        $orderId = $conn->insert_id;

        foreach ($cartItems as $item) {
            $conn->query("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES ($orderId, {$item['id']}, {$item['qty']}, {$item['price']})");
        }
        $_SESSION['cart'] = [];
        header("Location: /GadgetZone/pages/order_success.php?order=$orderNum");
        exit;
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container" style="padding-top:24px">
    <div class="breadcrumb">
        <a href="/GadgetZone/index.php">Home</a> <span>›</span>
        <a href="/GadgetZone/pages/cart.php">Cart</a> <span>›</span> Checkout
    </div>
    <div class="page-hero"><h1 class="page-hero-title">Checkout</h1></div>

    <?php if (!empty($errors)): ?>
    <div class="alert alert-error"><?= implode('<br>', $errors) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="checkout-layout">
            <div>
                <!-- CONTACT -->
                <div class="checkout-section">
                    <div class="section-step"><div class="step-num">1</div><div class="step-title">Contact Information</div></div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label class="form-label">First Name <span class="required">*</span></label>
                            <input type="text" name="first_name" class="form-input" value="<?= htmlspecialchars($user['first_name'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Last Name <span class="required">*</span></label>
                            <input type="text" name="last_name" class="form-input" value="<?= htmlspecialchars($user['last_name'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email Address <span class="required">*</span></label>
                            <input type="email" name="email" class="form-input" value="<?= htmlspecialchars($user['email'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Phone Number <span class="required">*</span></label>
                            <input type="text" name="phone" class="form-input" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" required>
                        </div>
                    </div>
                </div>

                <!-- SHIPPING -->
                <div class="checkout-section">
                    <div class="section-step"><div class="step-num">2</div><div class="step-title">Shipping Address</div></div>
                    <div class="form-grid">
                        <div class="form-group full">
                            <label class="form-label">Street Address <span class="required">*</span></label>
                            <input type="text" name="address" class="form-input" value="<?= htmlspecialchars($user['address'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">City <span class="required">*</span></label>
                            <input type="text" name="city" class="form-input" value="<?= htmlspecialchars($user['city'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Country</label>
                            <input type="text" class="form-input" value="Jordan" readonly>
                        </div>
                        <div class="form-group full">
                            <label class="form-label">Order Notes (optional)</label>
                            <textarea name="notes" class="form-textarea" rows="3" placeholder="Any special delivery instructions..."></textarea>
                        </div>
                    </div>
                </div>

                <!-- PAYMENT -->
                <div class="checkout-section">
                    <div class="section-step"><div class="step-num">3</div><div class="step-title">Payment Method</div></div>
                    <div class="payment-methods">
                        <label class="payment-option selected">
                            <input type="radio" name="payment_method" value="cod" checked>
                            <div>
                                <div class="payment-label">💵 Cash on Delivery</div>
                                <div style="font-size:12px;color:var(--text2)">Pay when your order arrives — Free of charge</div>
                            </div>
                        </label>
                        <label class="payment-option">
                            <input type="radio" name="payment_method" value="visa">
                            <div>
                                <div class="payment-label">💳 Visa Card</div>
                                <div style="font-size:12px;color:var(--text2)">Pay securely with your Visa credit/debit card</div>
                            </div>
                            <span class="payment-badge">VISA</span>
                        </label>
                    </div>
                </div>
            </div>

            <!-- ORDER REVIEW -->
            <div class="order-review-sidebar">
                <div class="section-step" style="margin-bottom:16px"><div class="step-num" style="background:var(--surface2);color:var(--accent)">✓</div><div class="step-title">Order Review</div></div>
                <div class="review-items">
                    <?php foreach ($cartItems as $item): ?>
                    <div class="review-item">
                        <img src="<?= htmlspecialchars($item['image_url']) ?>" alt="" class="review-thumb">
                        <div>
                            <div class="review-name"><?= htmlspecialchars($item['name']) ?></div>
                            <div class="review-meta">Qty: <?= $item['qty'] ?></div>
                        </div>
                        <div class="review-price"><?= formatPrice($item['price'] * $item['qty']) ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="divider"></div>
                <div class="summary-row"><span>Subtotal</span><span><?= formatPrice($cartTotal) ?></span></div>
                <div class="summary-row"><span>Shipping</span><span><?= $shipping > 0 ? formatPrice($shipping) : '<span style="color:#34d399">Free</span>' ?></span></div>
                <div class="summary-row total"><span>Total</span><span><?= formatPrice($grand) ?></span></div>
                <button type="submit" class="btn-primary" style="width:100%;justify-content:center;padding:16px;font-size:16px;margin-top:16px">
                    Place Order — <?= formatPrice($grand) ?>
                </button>
                <div class="security-msg">🔒 Your information is secure &amp; encrypted</div>
            </div>
        </div>
    </form>
</div>

<script>
document.querySelectorAll('.payment-option').forEach(opt => {
    opt.addEventListener('click', () => {
        document.querySelectorAll('.payment-option').forEach(o => o.classList.remove('selected'));
        opt.classList.add('selected');
    });
});

// Stripe redirect
const stripeOpt = document.getElementById('stripe-option');
if (stripeOpt) {
    document.querySelector('form').addEventListener('submit', function(e) {
        if (stripeOpt.querySelector('input').checked) {
            e.preventDefault();
            window.location = '/GadgetZone/pages/stripe_checkout.php';
        }
    });
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
